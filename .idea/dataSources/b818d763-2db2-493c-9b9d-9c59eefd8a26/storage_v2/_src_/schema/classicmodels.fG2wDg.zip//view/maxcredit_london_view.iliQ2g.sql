create definer = root@localhost view maxcredit_london_view as
select `classicmodels`.`maxcredit_city_view`.`city`               AS `city`,
       `classicmodels`.`maxcredit_city_view`.`max(c.creditLimit)` AS `max(c.creditLimit)`
from `classicmodels`.`maxcredit_city_view`
where (`classicmodels`.`maxcredit_city_view`.`city` = 'London');

