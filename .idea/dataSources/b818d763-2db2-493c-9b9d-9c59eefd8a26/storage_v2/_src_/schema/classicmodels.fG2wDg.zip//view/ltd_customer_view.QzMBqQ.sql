create definer = root@localhost view ltd_customer_view as
select `classicmodels`.`usa_customers`.`customerNumber` AS `custno`,
       `classicmodels`.`usa_customers`.`customerName`   AS `custname`,
       `classicmodels`.`usa_customers`.`city`           AS `custcity`,
       `classicmodels`.`usa_customers`.`country`        AS `custcountry`
from `classicmodels`.`usa_customers`
where (`classicmodels`.`usa_customers`.`customerName` like '%Ltd.');

