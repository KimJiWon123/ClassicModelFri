create definer = root@localhost view mini_customer_view as
select `c`.`customerName` AS `customerName`
from `classicmodels`.`customers` `c`
where (`c`.`customerName` like 'Mini%');

