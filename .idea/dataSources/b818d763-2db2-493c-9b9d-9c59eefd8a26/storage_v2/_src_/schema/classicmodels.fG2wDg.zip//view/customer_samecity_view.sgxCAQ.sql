create definer = root@localhost view customer_samecity_view as
select `c`.`customerName` AS `cust_name`, `c`.`city` AS `cust_city`
from ((`classicmodels`.`customers` `c` join `classicmodels`.`employees` `e`
       on ((`c`.`salesRepEmployeeNumber` = `e`.`employeeNumber`))) join `classicmodels`.`offices` `o`
      on ((`o`.`officeCode` = `e`.`officeCode`)))
where (`c`.`city` = `o`.`city`);

