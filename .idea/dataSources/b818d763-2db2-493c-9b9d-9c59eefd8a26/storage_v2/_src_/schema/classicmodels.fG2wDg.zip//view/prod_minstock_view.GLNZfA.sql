create definer = root@localhost view prod_minstock_view as
select `p`.`productName` AS `productName`, `p`.`quantityInStock` AS `quantityInStock`
from `classicmodels`.`products` `p`
where (`p`.`quantityInStock` = (select min(`p2`.`quantityInStock`) from `classicmodels`.`products` `p2`));

