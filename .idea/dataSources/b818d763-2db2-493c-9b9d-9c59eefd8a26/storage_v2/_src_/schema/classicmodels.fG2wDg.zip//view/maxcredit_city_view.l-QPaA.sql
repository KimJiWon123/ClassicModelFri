create definer = root@localhost view maxcredit_city_view as
select `c`.`city` AS `city`, max(`c`.`creditLimit`) AS `max(c.creditLimit)`
from `classicmodels`.`customers` `c`
group by `c`.`city`;

