create definer = root@localhost view totalamount_orders_view as
select `o`.`orderNumber`            AS `orderno`,
       `o`.`orderDate`              AS `orderDate`,
       (select sum(`od`.`quantityOrdered`)
        from `classicmodels`.`orderdetails` `od`
        where (`o`.`orderNumber` = `od`.`orderNumber`)
        group by `o`.`orderNumber`) AS `total_amount`
from `classicmodels`.`orders` `o`
order by (select sum(`od`.`quantityOrdered`)
          from `classicmodels`.`orderdetails` `od`
          where (`o`.`orderNumber` = `od`.`orderNumber`)
          group by `o`.`orderNumber`) desc;

